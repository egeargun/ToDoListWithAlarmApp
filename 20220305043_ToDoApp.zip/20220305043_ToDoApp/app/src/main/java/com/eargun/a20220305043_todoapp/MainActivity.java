package com.eargun.a20220305043_todoapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton fab;
    DatabaseHelper db;
    List<TaskModel> taskList;
    ToDoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.tasksRecyclerView);
        fab = findViewById(R.id.fab);

        db = new DatabaseHelper(this);
        taskList = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadTasks();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(intent);
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
    }

    private void loadTasks() {
        taskList = db.getAllTasks();

        adapter = new ToDoAdapter(this, taskList, db);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new ToDoAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int position) {
                TaskModel task = taskList.get(position);
                db.deleteTask(task.getId());
                taskList.remove(position);
                adapter.notifyItemRemoved(position);
                Toast.makeText(MainActivity.this, "Reminder Deleted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStatusChange(int position, boolean isDone) {
                TaskModel task = taskList.get(position);
                task.setStatus(isDone ? 1 : 0);
            }
        });
    }
}