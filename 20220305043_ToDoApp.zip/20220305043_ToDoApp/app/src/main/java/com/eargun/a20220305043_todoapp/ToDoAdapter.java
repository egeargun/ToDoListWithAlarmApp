package com.eargun.a20220305043_todoapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.MyViewHolder> {

    private Context context;
    private List<TaskModel> taskList;
    private DatabaseHelper db;

    // MainActivity ile iletişim kurmak için basit bir arayüz tanımlıyoruz
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(int position);
        void onStatusChange(int position, boolean isDone);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Kurucu Metot
    public ToDoAdapter(Context context, List<TaskModel> taskList, DatabaseHelper db) {
        this.context = context;
        this.taskList = taskList;
        this.db = db;
    }

    // Listeyi güncellemek için yardımcı metot
    public void updateList(List<TaskModel> newList) {
        this.taskList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.task_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // Verileri yerine koyma işlemi
        TaskModel task = taskList.get(position);

        holder.checkBox.setText(task.getTitle());
        holder.checkBox.setChecked(task.getStatus() == 1); // 1 ise işaretli, 0 ise işaretsiz
        holder.dateText.setText(task.getDate());

        // Checkbox işaretlendiğinde/kaldırıldığında ne olacak?
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (listener != null) {
                listener.onStatusChange(position, isChecked);
            }
        });

        // Silme butonuna basıldığında ne olacak?
        holder.deleteBtn.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    // Görünüm Tutucu (ViewHolder) Sınıfı
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView dateText;
        ImageView deleteBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.todoCheckBox);
            dateText = itemView.findViewById(R.id.taskDate);
            deleteBtn = itemView.findViewById(R.id.deleteTask);
        }
    }
}
