package com.eargun.a20220305043_todoapp;

public class TaskModel {
    private int id;
    private String title;
    private String description;
    private String date; // Tarih ve Saati String olarak tutacağız
    private int status;  // 0: Yapılmadı, 1: Yapıldı

    // Kurucu Metot (Constructor)
    public TaskModel(int id, String title, String description, String date, int status) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.status = status;
    }

    // Getter ve Setter Metotları (Veriye ulaşmak ve değiştirmek için)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
}